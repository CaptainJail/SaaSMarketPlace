<?php
// plugins/birthday/plugin.php

function init_birthday() {
    // Widget admin
    if (PluginSettings::get('birthday', 'show_admin', true)) {
        add_filter('zone.dashboard.bottom', 'birthday_render_admin_widget');
    }

    // Widget worker
    if (PluginSettings::get('birthday', 'show_worker', true)) {
        add_filter('zone.worker.home.bottom', 'birthday_render_worker_widget');
    }

    // API worker
    add_filter('worker.dashboard_response', 'birthday_add_to_worker_response', 10, 2);
}

/* ============================================================
   LÓGICA
   ============================================================ */

function birthday_get_upcoming($days = null) {
    if ($days === null) $days = (int) PluginSettings::get('birthday', 'days_ahead', 30);

    $field = birthday_find_field();
    if (!$field) return [];

    try {
        $rows = Database::fetchAll(
            "SELECT u.id, u.name, u.avatar, u.email, pv.value AS birthday
             FROM users u
             JOIN profile_values pv ON pv.user_id = u.id
             WHERE pv.field_id = ?
               AND pv.value IS NOT NULL AND pv.value != ''
               AND u.status = 'active'",
            [$field['id']]
        );
    } catch (Throwable $e) {
        PluginLog::error('birthday', 'Query error: ' . $e->getMessage());
        return [];
    }

    $upcoming = [];
    $today = new DateTime(); $today->setTime(0,0,0);
    $currentYear = (int)$today->format('Y');

    foreach ($rows as $r) {
        try {
            $raw = trim($r['birthday']);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) $bday = new DateTime($raw);
            elseif (preg_match('/^\d{2}-\d{2}$/', $raw)) $bday = new DateTime($currentYear . '-' . $raw);
            else $bday = new DateTime($raw);
        } catch (Exception $e) { continue; }

        $next = new DateTime();
        $next->setDate($currentYear, (int)$bday->format('m'), (int)$bday->format('d'));
        $next->setTime(0,0,0);
        if ($next < $today) $next->modify('+1 year');

        $diff = (int)$today->diff($next)->days;
        if ($diff <= $days) {
            $age = null;
            $by = (int)$bday->format('Y');
            if ($by > 1900 && $by <= $currentYear) $age = (int)$next->format('Y') - $by;

            $upcoming[] = [
                'user_id' => (int)$r['id'],
                'name' => $r['name'],
                'avatar_url' => $r['avatar'] ? UPLOAD_URL . '/' . $r['avatar'] : null,
                'in_days' => $diff,
                'date' => $next->format('d/m'),
                'day_name' => birthday_day_name($next->format('N')),
                'is_today' => $diff === 0,
                'is_tomorrow' => $diff === 1,
                'age' => $age,
            ];
        }
    }

    usort($upcoming, function($a, $b) {
        if ($a['in_days'] === $b['in_days']) return strcmp($a['name'], $b['name']);
        return $a['in_days'] - $b['in_days'];
    });

    $max = (int) PluginSettings::get('birthday', 'max_display', 5);
    return array_slice($upcoming, 0, $max);
}

function birthday_find_field() {
    return Database::fetch("SELECT * FROM profile_fields WHERE label LIKE '%umple%' OR label LIKE '%birthday%' LIMIT 1");
}

function birthday_day_name($n) {
    $d = ['', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
    return $d[(int)$n] ?? '';
}

/* ============================================================
   WIDGET ADMIN
   ============================================================ */

function birthday_render_admin_widget($content = '') {
    $accent = PluginSettings::get('birthday', 'accent_color', '#ec4899');
    $upcoming = birthday_get_upcoming();
    $todayCount = count(array_filter($upcoming, function($u){ return $u['is_today']; }));
    $daysAhead = (int) PluginSettings::get('birthday', 'days_ahead', 30);

    ob_start();
    ?>
    <div class="panel" style="margin-top:20px;">
        <div class="panel-header">
            <h5>
                <span class="panel-icon" style="background:linear-gradient(135deg,<?= Helpers::e($accent) ?>,#8b5cf6);">
                    <i class="bi bi-gift-fill"></i>
                </span>
                Próximos cumpleaños
                <?php if ($todayCount > 0): ?>
                    <span style="margin-left:8px;padding:3px 10px;background:linear-gradient(135deg,<?= Helpers::e($accent) ?>,#8b5cf6);color:#fff;border-radius:20px;font-size:.68rem;font-weight:800;text-transform:uppercase;">
                        ¡<?= $todayCount ?> hoy!
                    </span>
                <?php endif; ?>
            </h5>
        </div>

        <?php if (empty($upcoming)): ?>
            <div style="padding:32px 20px;text-align:center;color:#94a3b8;">
                <i class="bi bi-cake2" style="font-size:2rem;opacity:.3;display:block;margin-bottom:10px;"></i>
                <p style="margin:0;font-size:.88rem;font-weight:500;">Sin cumpleaños en los próximos <?= $daysAhead ?> días</p>
            </div>
        <?php else: ?>
            <div class="activity-list">
                <?php foreach ($upcoming as $u): ?>
                    <?php
                        $avatarStyle = $u['is_today'] ? 'background:linear-gradient(135deg,' . $accent . ',#8b5cf6);color:#fff;' : '';
                        $timeColor = $u['is_today'] ? $accent : ($u['is_tomorrow'] ? '#d97706' : '');
                        $timeLabel = $u['is_today'] ? 'Hoy' : ($u['is_tomorrow'] ? 'Mañana' : 'En ' . $u['in_days'] . ' días');
                    ?>
                    <div class="activity-item">
                        <div class="activity-avatar" style="<?= $avatarStyle ?>">
                            <?php if (!empty($u['avatar_url'])): ?>
                                <img src="<?= Helpers::e($u['avatar_url']) ?>" alt="">
                            <?php else: ?>
                                <?= strtoupper(mb_substr($u['name'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                        <div class="activity-body">
                            <div class="activity-title">
                                <strong><?= Helpers::e($u['name']) ?></strong>
                                <?php if ($u['age']): ?>
                                    <span style="color:#94a3b8;font-weight:500;font-size:.8rem;">cumple <?= (int)$u['age'] ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="activity-subtitle">
                                <span class="badge-tag" style="background:rgba(99,102,241,.1);color:#6366f1;">
                                    <i class="bi bi-calendar-heart"></i> <?= Helpers::e($u['date']) ?>
                                </span>
                                <span style="font-size:.72rem;color:#94a3b8;"><?= Helpers::e($u['day_name']) ?></span>
                            </div>
                        </div>
                        <div class="activity-time" style="<?= $timeColor ? 'color:' . $timeColor . ';font-weight:700;' : '' ?>">
                            <?= Helpers::e($timeLabel) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return $content . ob_get_clean();
}

/* ============================================================
   WIDGET WORKER
   ============================================================ */

function birthday_render_worker_widget($content = '') {
    $upcoming = birthday_get_upcoming();
    if (empty($upcoming)) return $content;
    $accent = PluginSettings::get('birthday', 'accent_color', '#ec4899');

    ob_start();
    ?>
    <div class="section-header" style="margin-top:22px;">
        <div class="section-title">
            <span class="dot" style="background:<?= Helpers::e($accent) ?>;"></span>
            Cumpleaños
        </div>
    </div>
    <div class="activity-card">
        <?php foreach ($upcoming as $u): ?>
            <?php
                $isToday = $u['is_today'];
                $avatarStyle = $isToday ? 'background:linear-gradient(135deg,' . $accent . ',#8b5cf6);color:#fff;' : '';
                $timeLabel = $isToday ? 'Hoy' : ($u['is_tomorrow'] ? 'Mañana' : 'En ' . $u['in_days'] . 'd');
                $timeColor = $isToday ? $accent : ($u['is_tomorrow'] ? '#d97706' : '');
            ?>
            <div class="activity-item">
                <div class="activity-avatar" style="<?= $avatarStyle ?>">
                    <?php if (!empty($u['avatar_url'])): ?>
                        <img src="<?= Helpers::e($u['avatar_url']) ?>" alt="">
                    <?php else: ?>
                        <?= strtoupper(mb_substr($u['name'], 0, 1)) ?>
                    <?php endif; ?>
                </div>
                <div class="activity-body">
                    <div class="activity-name"><?= Helpers::e($u['name']) ?></div>
                    <div class="activity-desc"><?= Helpers::e($u['date']) ?> · <?= Helpers::e($u['day_name']) ?></div>
                </div>
                <div class="activity-time" style="<?= $timeColor ? 'color:' . $timeColor . ';font-weight:700;' : '' ?>">
                    <?= Helpers::e($timeLabel) ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return $content . ob_get_clean();
}

function birthday_add_to_worker_response($response, $user = null) {
    if (is_array($response) && !empty($response['success'])) {
        $response['birthdays'] = birthday_get_upcoming();
    }
    return $response;
}