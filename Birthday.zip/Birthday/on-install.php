<?php
// plugins/birthday/on-install.php
// Se ejecuta al registrar el plugin

// Auto-crear el campo "Cumpleaños" si no existe
$existing = Database::fetch(
    "SELECT id FROM profile_fields WHERE label LIKE ? OR label LIKE ? LIMIT 1",
    ['%umple%', '%birthday%']
);

if (!$existing) {
    $maxOrder = (int) (Database::fetch("SELECT MAX(sort_order) m FROM profile_fields")['m'] ?? 0);

    Database::insert('profile_fields', [
        'label' => 'Cumpleaños',
        'field_type' => 'date',
        'options' => null,
        'required' => 0,
        'sort_order' => $maxOrder + 1,
    ]);

    PluginLog::info('birthday', 'Campo "Cumpleaños" creado automáticamente');
}