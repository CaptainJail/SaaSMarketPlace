<?php
// plugins/birthday/on-uninstall.php
PluginLog::info('birthday', 'Plugin desinstalado');
// Los datos se conservan